package com.axiom.launcher;

import com.axiom.launcher.ui.LauncherWindow;
import com.formdev.flatlaf.FlatDarkLaf;

import javax.swing.*;

public class AxiomLauncher {

    public static final String VERSION      = "1.0.0";
    public static final String MC_VERSION   = "26.2";
    public static final String LOADER_VER   = "0.16.0";
    public static final String CLIENT_NAME  = "Axiom";

    public static void main(String[] args) {
        // FlatLaf dark theme — looks modern, no Swing default ugliness
        FlatDarkLaf.setup();

        // Custom accent color — purple to match Axiom branding
        UIManager.put("Component.accentColor",
                new java.awt.Color(0x9B59B6));

        SwingUtilities.invokeLater(() -> {
            LauncherWindow window = new LauncherWindow();
            window.setVisible(true);
        });
    }
}
