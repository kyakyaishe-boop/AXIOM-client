package com.axiom.launcher.ui;

import com.axiom.launcher.AxiomLauncher;
import com.axiom.launcher.auth.MojangAuth;
import com.axiom.launcher.core.GameLauncher;
import com.axiom.launcher.installer.FabricInstaller;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LauncherWindow extends JFrame {

    // Brand colors
    private static final Color BG_DARK      = new Color(0x12, 0x12, 0x1F);
    private static final Color BG_PANEL     = new Color(0x1A, 0x1A, 0x2E);
    private static final Color ACCENT       = new Color(0x6C, 0x34, 0x83);
    private static final Color ACCENT_HOVER = new Color(0x8E, 0x44, 0xAD);
    private static final Color TEXT_MAIN    = new Color(0xE0, 0xE0, 0xFF);
    private static final Color TEXT_SUB     = new Color(0x70, 0x70, 0x90);
    private static final Color GREEN_OK     = new Color(0x27, 0xAE, 0x60);
    private static final Color RED_ERR      = new Color(0xC0, 0x39, 0x2B);

    private JTextField  usernameField;
    private JPasswordField passwordField;
    private JLabel      statusLabel;
    private JButton     launchBtn;
    private JProgressBar progressBar;

    // Cached session
    private MojangAuth.Session session;

    public LauncherWindow() {
        setTitle("Axiom Client " + AxiomLauncher.VERSION);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(680, 400);
        setLocationRelativeTo(null);
        setResizable(false);
        setUndecorated(true); // custom title bar
        getContentPane().setBackground(BG_DARK);

        buildUI();
    }

    private void buildUI() {
        setLayout(new BorderLayout());

        // --- Custom title bar ---
        JPanel titleBar = new JPanel(new BorderLayout());
        titleBar.setBackground(BG_PANEL);
        titleBar.setPreferredSize(new Dimension(0, 36));
        titleBar.setBorder(new EmptyBorder(0, 12, 0, 8));

        JLabel title = new JLabel("AXIOM CLIENT  ·  " + AxiomLauncher.MC_VERSION);
        title.setForeground(TEXT_MAIN);
        title.setFont(new Font("Segoe UI", Font.BOLD, 13));
        titleBar.add(title, BorderLayout.WEST);

        // Close + minimize buttons
        JPanel winBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 6));
        winBtns.setBackground(BG_PANEL);
        winBtns.add(makeWinBtn("—", e -> setState(ICONIFIED)));
        winBtns.add(makeWinBtn("✕", e -> System.exit(0)));
        titleBar.add(winBtns, BorderLayout.EAST);

        // Drag to move
        MouseAdapter drag = new MouseAdapter() {
            Point start;
            public void mousePressed(MouseEvent e)  { start = e.getPoint(); }
            public void mouseDragged(MouseEvent e)  {
                Point loc = getLocation();
                setLocation(loc.x + e.getX() - start.x, loc.y + e.getY() - start.y);
            }
        };
        titleBar.addMouseListener(drag);
        titleBar.addMouseMotionListener(drag);
        add(titleBar, BorderLayout.NORTH);

        // --- Left panel: branding ---
        JPanel left = new JPanel();
        left.setBackground(BG_PANEL);
        left.setPreferredSize(new Dimension(240, 0));
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setBorder(new EmptyBorder(40, 30, 40, 30));

        JLabel logo = new JLabel("AXIOM");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 32));
        logo.setForeground(new Color(0xC0, 0xA8, 0xFF));
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel sub = new JLabel("Minecraft " + AxiomLauncher.MC_VERSION);
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sub.setForeground(TEXT_SUB);
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel ver = new JLabel("v" + AxiomLauncher.VERSION);
        ver.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        ver.setForeground(TEXT_SUB);
        ver.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Module count badge
        JLabel badge = new JLabel("15 modules loaded");
        badge.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        badge.setForeground(new Color(0x2E, 0xCC, 0x71));
        badge.setAlignmentX(Component.LEFT_ALIGNMENT);

        left.add(logo);
        left.add(Box.createRigidArea(new Dimension(0, 4)));
        left.add(sub);
        left.add(Box.createRigidArea(new Dimension(0, 2)));
        left.add(ver);
        left.add(Box.createRigidArea(new Dimension(0, 20)));
        left.add(badge);
        add(left, BorderLayout.WEST);

        // --- Right panel: auth + launch ---
        JPanel right = new JPanel();
        right.setBackground(BG_DARK);
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.setBorder(new EmptyBorder(40, 40, 30, 40));

        JLabel loginTitle = new JLabel("SIGN IN");
        loginTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginTitle.setForeground(TEXT_MAIN);
        loginTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        usernameField = styledField("Minecraft Email");
        passwordField = new JPasswordField();
        styleComponent(passwordField, "Password");

        JButton loginBtn = styledButton("Sign In", ACCENT, ACCENT_HOVER);
        loginBtn.addActionListener(e -> doLogin());

        statusLabel = new JLabel(" ");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        statusLabel.setForeground(TEXT_SUB);
        statusLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        progressBar = new JProgressBar();
        progressBar.setIndeterminate(false);
        progressBar.setVisible(false);
        progressBar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 6));
        progressBar.setBackground(BG_PANEL);
        progressBar.setForeground(ACCENT);

        launchBtn = styledButton("LAUNCH", GREEN_OK, new Color(0x1E, 0x8B, 0x4C));
        launchBtn.setEnabled(false);
        launchBtn.addActionListener(e -> doLaunch());

        right.add(loginTitle);
        right.add(Box.createRigidArea(new Dimension(0, 16)));
        right.add(usernameField);
        right.add(Box.createRigidArea(new Dimension(0, 8)));
        right.add(passwordField);
        right.add(Box.createRigidArea(new Dimension(0, 12)));
        right.add(loginBtn);
        right.add(Box.createRigidArea(new Dimension(0, 10)));
        right.add(statusLabel);
        right.add(Box.createVerticalGlue());
        right.add(progressBar);
        right.add(Box.createRigidArea(new Dimension(0, 10)));
        right.add(launchBtn);

        add(right, BorderLayout.CENTER);
    }

    // --- Auth flow ---

    private void doLogin() {
        String email = usernameField.getText().trim();
        String pass  = new String(passwordField.getPassword());

        if (email.isEmpty() || pass.isEmpty()) {
            setStatus("Enter email and password.", RED_ERR);
            return;
        }

        setStatus("Authenticating...", TEXT_SUB);
        progressBar.setIndeterminate(true);
        progressBar.setVisible(true);

        SwingWorker<MojangAuth.Session, Void> worker = new SwingWorker<>() {
            @Override
            protected MojangAuth.Session doInBackground() throws Exception {
                return MojangAuth.authenticate(email, pass);
            }

            @Override
            protected void done() {
                progressBar.setIndeterminate(false);
                progressBar.setVisible(false);
                try {
                    session = get();
                    setStatus("Signed in as " + session.username, GREEN_OK);
                    launchBtn.setEnabled(true);
                } catch (Exception ex) {
                    setStatus("Auth failed: " + ex.getMessage(), RED_ERR);
                }
            }
        };
        worker.execute();
    }

    // --- Launch flow ---

    private void doLaunch() {
        if (session == null) {
            setStatus("Sign in first.", RED_ERR);
            return;
        }

        launchBtn.setEnabled(false);
        progressBar.setIndeterminate(true);
        progressBar.setVisible(true);
        setStatus("Checking Fabric install...", TEXT_SUB);

        SwingWorker<Void, String> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                publish("Installing Fabric " + AxiomLauncher.LOADER_VER + "...");
                FabricInstaller.ensureInstalled(
                        AxiomLauncher.MC_VERSION,
                        AxiomLauncher.LOADER_VER
                );

                publish("Deploying Axiom mod...");
                FabricInstaller.deployMod();

                publish("Launching Minecraft " + AxiomLauncher.MC_VERSION + "...");
                GameLauncher.launch(session, AxiomLauncher.MC_VERSION);
                return null;
            }

            @Override
            protected void process(java.util.List<String> chunks) {
                setStatus(chunks.get(chunks.size() - 1), TEXT_SUB);
            }

            @Override
            protected void done() {
                progressBar.setIndeterminate(false);
                progressBar.setVisible(false);
                try {
                    get();
                    setStatus("Game launched.", GREEN_OK);
                } catch (Exception ex) {
                    setStatus("Launch failed: " + ex.getMessage(), RED_ERR);
                    launchBtn.setEnabled(true);
                }
            }
        };
        worker.execute();
    }

    // --- UI helpers ---

    private void setStatus(String msg, Color color) {
        statusLabel.setText(msg);
        statusLabel.setForeground(color);
    }

    private JTextField styledField(String placeholder) {
        JTextField f = new JTextField();
        styleComponent(f, placeholder);
        return f;
    }

    private void styleComponent(JTextField f, String placeholder) {
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        f.setBackground(new Color(0x1E, 0x1E, 0x38));
        f.setForeground(TEXT_MAIN);
        f.setCaretColor(TEXT_MAIN);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0x40, 0x40, 0x60), 1),
                new EmptyBorder(4, 8, 4, 8)
        ));
        f.putClientProperty("JTextField.placeholderText", placeholder);
        f.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    private JButton styledButton(String text, Color bg, Color hover) {
        JButton b = new JButton(text);
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { b.setBackground(hover); }
            public void mouseExited(MouseEvent e)  { b.setBackground(bg); }
        });
        return b;
    }

    private JButton makeWinBtn(String label, java.awt.event.ActionListener action) {
        JButton b = new JButton(label);
        b.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        b.setForeground(TEXT_SUB);
        b.setBackground(BG_PANEL);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(32, 24));
        b.addActionListener(action);
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { b.setForeground(TEXT_MAIN); }
            public void mouseExited(MouseEvent e)  { b.setForeground(TEXT_SUB); }
        });
        return b;
    }
}
